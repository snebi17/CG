# CG
Seminar for Computer Graphics on FRI.
